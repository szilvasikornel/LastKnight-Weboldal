document.addEventListener("DOMContentLoaded", function () {
    const settingsIcon = document.getElementById("settings-icon");
    const dropdownMenu = document.getElementById("dropdown-menu");

    if (settingsIcon && dropdownMenu) {
        settingsIcon.addEventListener("click", function (event) {
            event.preventDefault();
            dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
        });

        // Ha máshová kattintunk, záródjon be a menü
        document.addEventListener("click", function (event) {
            if (!settingsIcon.contains(event.target) && !dropdownMenu.contains(event.target)) {
                dropdownMenu.style.display = "none";
            }
        });
    }
    const images = document.querySelectorAll('.image');
    const modal = document.getElementById('myModal');
    const modalImg = document.getElementById("modalImage");
    const closeBtn = document.querySelector('.close'); // Kiválasztjuk a bezáró gombot

    // A képek kattintásának figyelése
    images.forEach(function(image) {
        image.addEventListener('click', function() {
            modal.style.display = "flex"; // Megjelenítjük a modált flexbox-al
            modalImg.src = this.src; // Beállítjuk a nagy képet
        });
    });

    // A modális ablak bezárása
    function closeModal() {
        modal.style.display = "none"; // Elrejtjük a modált
    }

    // A bezáró gombot hozzáadjuk
    closeBtn.addEventListener('click', closeModal);

    // Ha a háttérre kattintasz, szintén bezárja a modált
    modal.addEventListener('click', function(event) {
        if (event.target === modal) {
            closeModal(); // Ha a háttérre kattintasz, bezárja a modált
        }
    });
});
