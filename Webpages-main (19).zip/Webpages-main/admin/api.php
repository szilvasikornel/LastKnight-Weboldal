<?php
//Adatok json formátumban való tárolása
include 'connect.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=utf-8");

$requestMethod = $_SERVER["REQUEST_METHOD"];
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

switch ($requestMethod) {
    case "GET":
        if ($id) {
            getUserById($conn, $id);
        } else {
            getAllUsers($conn);
        }
        break;
    case "POST":
        if (isset($_GET['type']) && $_GET['type'] === 'content') {
            createContent($conn);
        } else {
            createUser($conn);
        }
        break;
    case "PUT":
        if ($id) {
            updateUser($conn, $id);
        } else {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "Hiányzik a felhasználó azonosítója"]);
        }
        break;
    case "DELETE":
        if ($id) {
            deleteUser($conn, $id);
        } else {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "Hiányzik a felhasználó azonosítója a törléshez"]);
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(["status" => "error", "message" => "Nem támogatott HTTP típus"]);
}

// GET egy felhasználó ID alapján
function getUserById($conn, $id) {
    $query = "SELECT * FROM Users WHERE ID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    // Ellenőrzi, hogy van-e találat
    if ($result->num_rows > 0) {
        http_response_code(200);
        echo json_encode(['status' => 'success', 'data' => $result->fetch_assoc()]);
    } else {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Felhasználó nem található.']);
    }
}

// GET összes felhasználó
function getAllUsers($conn) {
    $query = "SELECT * FROM Users";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $data = mysqli_fetch_all($result, MYSQLI_ASSOC);
        http_response_code(200);
        echo json_encode(["status" => "success", "data" => $data]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Adatbázis hiba: " . mysqli_error($conn)]);
    }
}

// POST új felhasználó létrehozása
function createUser($conn) {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!$data || !isset($data['name'], $data['email'], $data['password'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Hiányos adatok.']);
        return;
    }

    $passwordHash = password_hash($data['password'], PASSWORD_BCRYPT);

    $query = "INSERT INTO Users (Name, Email, Password, Role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sssi', $data['name'], $data['email'], $passwordHash, $data['role']);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(['status' => 'success', 'message' => 'Felhasználó sikeresen létrehozva.', 'id' => $stmt->insert_id]);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Hiba az adat létrehozásakor.']);
    }
}

// PUT felhasználó frissítése
function updateUser($conn, $id) {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!$data) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Hiányos adatok.']);
        return;
    }

    $query = "UPDATE Users SET Name = ?, Email = ?, Password = ?, Role = ? WHERE ID = ?";
    $stmt = $conn->prepare($query);
    $passwordHash = password_hash($data['password'], PASSWORD_BCRYPT);
    $stmt->bind_param('sssii', $data['name'], $data['email'], $passwordHash, $data['role'], $id);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(['status' => 'success', 'message' => 'Felhasználó sikeresen frissítve.']);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Hiba a frissítés során.']);
    }
}

// DELETE felhasználó törlése
function deleteUser($conn, $id) {
    $query = "DELETE FROM Users WHERE ID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        http_response_code(204);
        echo json_encode(['status' => 'success', 'message' => 'Felhasználó sikeresen törölve lett.']);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Hiba a törlés során.']);
    }
}

// POST új tartalom létrehozása (Content)
function createContent($conn) {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!$data || !isset($data['user_id'], $data['title'], $data['content'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Hiányos adatok.']);
        return;
    }

    $query = "INSERT INTO Content (UserID, Title, Content) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('iss', $data['user_id'], $data['title'], $data['content']);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(['status' => 'success', 'message' => 'Tartalom sikeresen létrehozva.', 'id' => $stmt->insert_id]);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Hiba a tartalom létrehozásakor.']);
    }
}

mysqli_close($conn);
?>

