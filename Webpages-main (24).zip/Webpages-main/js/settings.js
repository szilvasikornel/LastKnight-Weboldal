function showDeleteModal() {
    document.getElementById("deleteModal").style.display = "flex";
}

function closeModal() {
    document.getElementById("deleteModal").style.display = "none";
}

function deleteAccount() {
    let form = document.createElement("form");
    form.method = "POST";
    form.action = "settings.php";

    let input = document.createElement("input");
    input.type = "hidden";
    input.name = "delete_account";
    input.value = "1";
    
    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
}
        

        setTimeout(() => {
            const successMessage = document.querySelector('.success-message');
            if (successMessage) {
                successMessage.style.display = 'none';
            }
        }, 3000);