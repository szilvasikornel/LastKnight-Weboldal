<?php
require '../admin/connect.php'; // Kötjük a kapcsolatot az adatbázissal
session_start();

// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Felhasználói adatok lekérése
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM Users WHERE ID = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

// Ha nincs találat, irányítsuk el a login oldalra
if (!$user) {
    header("Location: login.php");
    exit;
}

// Szerep ellenőrzése (admin = 1, user = 0)
$role = $user['Role'];  // Ez a változó most már definiálva lesz
$is_admin = ($role == 1) ? true : false;

// Tartalom lekérése az adatbázisból
$sql = "SELECT * FROM Content ORDER BY CreatedAt DESC";
$result = mysqli_query($conn, $sql);
$contentData = [];  // Kezdetben üres tömb

while ($row = mysqli_fetch_assoc($result)) {
    $contentData[] = $row;  // Feltöltjük a tartalom adatokat
}

// Ha POST kérés érkezik a tartalom mentésére
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Új tartalom hozzáadása
    if (isset($_POST['action']) && $_POST['action'] == 'saveContent') {
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $content = mysqli_real_escape_string($conn, $_POST['content']);

        // Az új tartalom beszúrása az adatbázisba
        $sql = "INSERT INTO Content (Title, Content, UserID, CreatedAt) VALUES (?, ?, ?, NOW())";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $title, $content, $user_id);

        if (mysqli_stmt_execute($stmt)) {
            echo "Tartalom sikeresen hozzáadva!";
        } else {
            echo "Hiba történt a tartalom hozzáadása során!";
        }
    }

    // Tartalom módosítása
    if (isset($_POST['action']) && $_POST['action'] == 'updateContent') {
        $content_id = $_POST['content_id'];
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $content = mysqli_real_escape_string($conn, $_POST['content']);

        // Frissítjük a tartalmat az adatbázisban
        $sql = "UPDATE Content SET Title = ?, Content = ? WHERE ID = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $title, $content, $content_id);

        if (mysqli_stmt_execute($stmt)) {
            echo "Tartalom sikeresen frissítve!";
        } else {
            echo "Hiba történt a tartalom frissítése során!";
        }
    }

    // Tartalom törlése
    if (isset($_POST['action']) && $_POST['action'] == 'deleteContent') {
        $content_id = $_POST['content_id'];

        // Töröljük a tartalmat az adatbázisból
        $sql = "DELETE FROM Content WHERE ID = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $content_id);

        if (mysqli_stmt_execute($stmt)) {
            echo "Tartalom sikeresen törölve!";
        } else {
            echo "Hiba történt a tartalom törlésé során!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tartalom Kezelés</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/updates.css">
</head>
<body>
    <div class="wrapper">
        <?php include 'header/header.php'; ?>

        <div id="content-container">
            <?php if (empty($contentData)): ?>
                <!-- Ha nincs tartalom az adatbázisban -->
                <p class="no-content-message">Jelenleg nincs elérhető tartalom. Kérjük, próbálj meg később!</p>
            <?php else: ?>
                <?php foreach ($contentData as $item): ?>
                    <div class="content-block" data-id="<?php echo $item['ID']; ?>">
                        <h3 class="content-title"><?php echo $item['Title']; ?></h3>
                        <p class="content-text"><?php echo $item['Content']; ?></p>
                        <span class="created-at"><?php echo date("Y-m-d", strtotime($item['CreatedAt'])); ?></span>

                        <!-- Csak adminnak látható gombok -->
                        <?php if ($is_admin): ?>
                            <div class="block-actions">
                                <button class="edit-btn" onclick="editContent(this)">Módosítás</button>
                                <button class="delete-btn" onclick="deleteContent(this)">Törlés</button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Új tartalom hozzáadása gomb, csak adminnak -->
        <?php if ($is_admin): ?>
            <div class="center-btn-container">
                <button class="add-btn" onclick="addContentBlock()">Új tartalom hozzáadása</button>
            </div>
        <?php endif; ?>

        <?php include 'footer/footer.php'; ?>
    </div>

    <script>
    // Új tartalom hozzáadásakor eltüntetjük az üzenetet
    function addContentBlock() {
        let container = document.getElementById('content-container');
        let noContentMessage = document.querySelector('.no-content-message');
        
        // Ha létezik az üzenet, eltüntetjük
        if (noContentMessage) {
            noContentMessage.style.display = 'none';
        }

        let newBlock = document.createElement('div');
        newBlock.classList.add('content-block');
        newBlock.innerHTML = `
            <div class="content-header">
                <input type="text" placeholder="Cím" class="title-input">
            </div>
            <textarea placeholder="Tartalom" class="content-input"></textarea>
            <div class="content-actions">
                <button class="save-btn" onclick="saveContent(this)">Hozzáadás</button>
                <button class="cancel-btn" onclick="cancelContent(this)">Mégse</button>
            </div>
        `;
        container.insertBefore(newBlock, container.firstChild); // Insert above the button
    }

    function saveContent(button) {
        let block = button.parentElement.parentElement;
        let title = block.querySelector('.title-input').value;
        let content = block.querySelector('.content-input').value;

        if (title && content) {
            // Send to server to save in database
            fetch('updates.php', {
                method: 'POST',
                body: new URLSearchParams({
                    'action': 'saveContent',
                    'title': title,
                    'content': content
                })
            })
            .then(response => response.text())
            .then(data => {
                console.log(data);
                if (data.includes("sikeresen")) {
                    // Ha sikeres, akkor létrehozzuk az új blokkot
                    let currentDate = new Date().toISOString().slice(0, 10); // Csak a dátum
                    block.innerHTML = `
                        <h3>${title}</h3>
                        <p>${content}</p>
                        <span class="created-at">${currentDate}</span>
                        <div class="block-actions">
                            <button class="edit-btn" onclick="editContent(this)">Módosítás</button>
                            <button class="delete-btn" onclick="deleteContent(this)">Törlés</button>
                        </div>
                    `;
                } else {
                    alert("Hiba történt a mentés során!");
                }
            })
            .catch(error => console.error('Error:', error));
        } else {
            alert('Töltsd ki mindkét mezőt!');
        }
    }

    function cancelContent(button) {
        let block = button.parentElement.parentElement;

        // Ha a blokk szerkesztés módban van, akkor állítsuk vissza a régi tartalmat
        if (block.querySelector('.title-input')) {
            let originalTitle = block.querySelector('.title-input').getAttribute('data-original-title');
            let originalContent = block.querySelector('.content-input').getAttribute('data-original-content');
            let originalCreatedAt = block.querySelector('.created-at').getAttribute('data-original-createdAt');

            // Visszaállítjuk a blokk tartalmát
            block.innerHTML = `
                <h3>${originalTitle}</h3>
                <p>${originalContent}</p>
                <span class="created-at">${originalCreatedAt}</span>
                <div class="block-actions">
                    <button class="edit-btn" onclick="editContent(this)">Módosítás</button>
                    <button class="delete-btn" onclick="deleteContent(this)">Törlés</button>
                </div>
            `;
        }
    }

    function editContent(button) {
        let block = button.parentElement.parentElement;
        let title = block.querySelector('h3').textContent;
        let content = block.querySelector('p').textContent;
        let createdAt = block.querySelector('.created-at').textContent;
        let contentId = block.getAttribute('data-id');

        // Hozzáadjuk a data-original-* attribútumokat a mezőkhöz
        block.innerHTML = `
            <div class="content-header">
                <input type="text" value="${title}" class="title-input" data-original-title="${title}">
            </div>
            <textarea class="content-input" data-original-content="${content}">${content}</textarea>
            <span class="created-at" data-original-createdAt="${createdAt}">${createdAt}</span>
            <div class="content-actions">
                <button class="save-btn" onclick="updateContent(this, ${contentId})">Frissítés</button>
                <button class="cancel-btn" onclick="cancelContent(this)">Mégse</button>
            </div>
        `;
    }

    function updateContent(button, contentId) {
        let block = button.parentElement.parentElement;
        let title = block.querySelector('.title-input').value;
        let content = block.querySelector('.content-input').value;

        fetch('updates.php', {
            method: 'POST',
            body: new URLSearchParams({
                'action': 'updateContent',
                'content_id': contentId,
                'title': title,
                'content': content
            })
        })
        .then(response => response.text())
        .then(data => {
            console.log(data);
            if (data.includes("sikeresen")) {
                // Ha sikeres, frissítjük a blokkot
                block.innerHTML = `
                    <h3>${title}</h3>
                    <p>${content}</p>
                    <span class="created-at">${new Date().toISOString().slice(0, 10)}</span>
                    <div class="block-actions">
                        <button class="edit-btn" onclick="editContent(this)">Módosítás</button>
                        <button class="delete-btn" onclick="deleteContent(this)">Törlés</button>
                    </div>
                `;
            } else {
                alert("Hiba történt a frissítés során!");
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function deleteContent(button) {
        let block = button.parentElement.parentElement;
        let contentId = block.getAttribute('data-id');

        if (confirm('Biztosan törölni szeretnéd ezt a tartalmat?')) {
            fetch('updates.php', {
                method: 'POST',
                body: new URLSearchParams({
                    'action': 'deleteContent',
                    'content_id': contentId
                })
            })
            .then(response => response.text())
            .then(data => {
                if (data.includes("sikeresen")) {
                    block.remove();
                } else {
                    alert("Hiba történt a törlés során!");
                }
            })
            .catch(error => console.error('Error:', error));
        }
    }
    </script>
</body>
</html>
