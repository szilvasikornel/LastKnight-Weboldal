        // Modális ablak megjelenítése
        function showDeleteModal() {
            document.getElementById("deleteModal").style.display = "flex"; // Modális ablak megjelenítése
        }

        // Modális ablak bezárása
        function closeModal() {
            document.getElementById("deleteModal").style.display = "none"; // Modális ablak eltüntetése
        }

        function deleteAccount() {
            // Létrehozunk egy űrlapot, és elküldjük a törlési kérést
            let form = document.createElement("form");
            form.method = "POST";
            form.action = "settings.php";
        
            let input = document.createElement("input");
            input.type = "hidden";
            input.name = "delete_account";
            input.value = "1";
            
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
        

        setTimeout(() => {
            const successMessage = document.querySelector('.success-message');
            if (successMessage) {
                successMessage.style.display = 'none';
            }
        }, 3000);