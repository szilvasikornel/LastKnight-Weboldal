<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- FontAwesome ikonok betöltése -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="shortcut icon" href="../images/Új projekt.png" type="image/x-icon">

    <title>Document</title>
</head>
<body>
    <div class="wrapper">
    
        <?php include 'header/header.php'; ?> 

        <main>
            <div class="content">
                <div class="datas">
                    <h2>A játékról</h2>
                    <p>
                        A helyőrséged utolsó életben maradt tagjaként hatalmas felelősség nehezedik rád: neked kell figyelmeztetned a lovagi rendet a közelgő veszélyre. Egyetlen esélyük a túlélésre a te elszántságodon és kitartásodon múlik.
                        <br>
                        Bár a küldetés elsőre egyszerűnek tűnhet, az előtted tornyosuló akadályok szinte leküzdhetetlenek. A helyszín, ahol szolgáltál, egy elszigetelt szigeten fekszik, és az egyetlen menekülési útvonalad a túloldalán található. A természet vad ereje, az ismeretlen fenyegetések és a magány súlya mind próbára teszik akaraterődet.
                        <br>
                        Vajon képes vagy átvágni a veszélyekkel teli szigeten, hogy teljesítsd a küldetésed? A lovagi rend és talán az egész birodalom sorsa a te kezedben van!
                    </p>
                    <ul>
                        <li>
                            <video width="400px" controls>
                                <source src="../teaser/utomp3.com - dancing spinning floating ghost with low quality music_v144P.mp4" type="video/mp4">
                                <source src="../teaser/utomp3.com - dancing spinning floating ghost with low quality music_v144P.webm" type="video/webm">
                            </video>
                        </li>
                        <li>
                            <p>
                                Utazásod során számtalan félelmetes szörnnyel és halálos veszélyekkel kell szembenézned, hogy elérd a végső célodat. Minden egyes szint újabb és újabb kihívásokat tartogat, próbára téve bátorságodat, ügyességedet és stratégiádat. Egyetlen rossz döntés is végzetes lehet, de ha kellően figyelmes és kitartó vagy, minden akadályt legyőzhetsz.
                                <br>
                                Ahhoz, hogy sikerrel járj, nemcsak az erődre, hanem az eszedre is szükséged lesz. Fedezd fel a rejtett ösvényeket, gyűjtsd össze a hasznos tárgyakat, és használd ki a környezeted adta lehetőségeket. Ne feledd, az út nemcsak veszélyekkel, hanem szövetségesekkel is tele van! Segíts másokon, mert a bajtársiasság és az összefogás kulcsfontosságú lehet a túléléshez.
                                <br>
                                Vajon képes vagy túljárni ellenfeleid eszén, legyőzni a sötétség teremtményeit, és diadalt aratni a végső próbatételeken? A döntés és a sorsod a te kezedben van!
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="container">
                <div class="second">
                    <div class="screens">
                        <h2 id="second-phase">Képernyő tervek</h2>
                        <p>
                            A játékról készült néhány pillanatkép annak készítése és megjelenésével kapcsolatos képek 
                        </p>
                    </div>
                </div>
                
            </div>
            <div class="screen-img">
                <ul>
                    <li><img src="../images/kep2.png" alt="2" class="image"></li>
                    <li><img src="../images/kep5.png" alt="5" class="image"></li>
                    <li><img src="../images/kep3.png" alt="3" class="image"></li>
                    <li><img src="../images/kep4.png" alt="4" class="image"></li>
                    <li><img src="../images/kep1.png" alt="1" class="image"></li> 
                    <li><img src="../images/kep6.png" alt="6" class="image"></li>
                </ul>
            </div> 
        </main>
        <?php include 'footer/footer.php'; ?> 
    </div>
    
    <!-- A modális ablak -->
    <div id="myModal" class="modal" style="display: none;">
        <span class="close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="modalImage">
    </div>

    <script src="../js/dropdown.js"></script>
</body>
</html>