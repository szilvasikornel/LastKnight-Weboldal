<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/contact.css">
    <link rel="shortcut icon" href="../images/Új projekt.png" type="image/x-icon">
    <title>Contact Us</title>
</head>
<body>
    <div class="wrapper">

        <?php include 'header/header.php'; ?> 

    <main>
        <div class="content">
            <h2>Contact Us</h2>
            <p>If you have a question, suggestion, or feedback, feel free to reach out to us.</p>
            
            <div class="contact-info">
                <h3>Our Contact Information:</h3>
                <ul>
                    <li>Email: <a href="">contact@company.com</a></li>
                    <li>Phone: +36707312192</li>
                </ul>
            </div>
        </div>
    </main>

    <?php include 'footer/footer.php'; ?> 

</div>
</body>
</html>
