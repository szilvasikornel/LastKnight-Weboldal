<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/player.css">
    <link rel="shortcut icon" href="../images/Új projekt.png" type="image/x-icon">
    <title>Document</title>
</head>
<body>
    <div class="wrapper">
    
        <?php include 'header/header.php'; ?> 

    <main>
        <div class="content">
            <div class="datas">
                <h2>Profile</h2>              
                <div class="profile">
                    <img src="../images/yuri-kondo-knight1000.jpg" alt="profil">
                    <ul>
                        <li>Username: <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : '-'; ?></li>
                    </ul>
                    <ul>
                        <li>Character:</li>
                    </ul>
                    <ul>
                        <li>Coin:</li>
                    </ul>
                    <ul>
                        <li>Death Count:</li>
                    </ul>
                    <ul>
                        <li>Enemy:</li>
                    </ul>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer/footer.php'; ?> 

</div>
</body>
</html>
