    <!-- Navigációs sáv -->
    <nav>
        <div class="nav-left">
            <a href="../php/main.php">Főoldal</a>
            <a href="../php/download.php">Letöltés</a>
            <a href="../php/contact.php">Kapcsolat</a>
        </div>
        <div class="nav-right">
            <a href="../admin/login.php">Bejelentkezés</a>
            <a href="../admin/register.php">Regisztráció</a>
        </div>
    </nav>