<footer>
        <small>© 2025 jatekneve. Minden jog fenntartva.</small>
</footer>