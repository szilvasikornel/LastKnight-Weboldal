<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- FontAwesome ikonok betöltése -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/player.css">
    <link rel="shortcut icon" href="../images/Új projekt.png" type="image/x-icon">
    <title>Document</title>
</head>
<body>
    <div class="wrapper">
    
        <?php include 'header/header.php'; ?> 

    <main>
        <div class="content">
            <div class="datas">
                <h2>Profil</h2>              
                <div class="profile">
                    <img src="../images/yuri-kondo-knight1000.jpg" alt="profil" class="profile-img">
                    <ul>
                        <li>Felhasználónév: <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : '-'; ?></li>
                    </ul>
                    <ul>
                        <li>Érmék száma: <span class="counts"> 43 </span><img src="../images/Coin-Sheet.png" alt="coin" class="icons"></li>
                    </ul>
                    <ul>
                        <li>Halálok száma: <span class="counts"> 3 </span><img src="../images/halalfej.png" alt="death" class="icons"></li>
                    </ul>
                    <ul>
                        <li>Megölt ellenségek: <span class="counts"> 11 </span><img src="../images/goblin.png" alt="enemy" class="icons"></li>
                    </ul>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer/footer.php'; ?> 

</div>
</body>
</html>
