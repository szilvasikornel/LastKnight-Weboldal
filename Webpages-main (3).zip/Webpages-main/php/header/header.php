<?php
session_start();
?>

<nav>
    <div class="nav-left">
        <a href="../php/main.php">Főoldal</a>
        <a href="../php/download.php">Letöltés</a>
        <a href="../php/contact.php">Kapcsolat</a>
    </div>
    <div class="nav-right">
        <?php if (!empty($_SESSION['username'])): ?>
            <!-- Beállítás ikon -->
            <div class="settings-dropdown">
                <a href="#" id="settings-icon">
                    <i class="fas fa-cog" style="font-size: 1.5em;"></i>
                </a>
                <div class="dropdown-menu" id="dropdown-menu">
                    <a href="../php/player.php">Profil</a>
                    <a href="../php/settings.php">Beállítások</a>
                    <a href="../php/logout.php">Kijelentkezés</a>
                </div>
            </div>
        <?php else: ?>
            <a href="../admin/login.php">Bejelentkezés</a>
            <a href="../admin/register.php">Regisztráció</a>
        <?php endif; ?>
    </div>
</nav>
