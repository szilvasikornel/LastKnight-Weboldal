function confirmDelete() {
    return confirm("Biztosan törölni szeretnéd a fiókodat? Ez a művelet visszafordíthatatlan!");
}