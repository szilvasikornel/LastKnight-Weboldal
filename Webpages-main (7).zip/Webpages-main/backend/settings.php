<?php

session_start();  // A session indítása a fájl elején

include('../admin/connect.php');

// Ellenőrizzük, hogy a session-ban létezik-e a felhasználónév
if (!isset($_SESSION['username'])) {
    // Ha nincs bejelentkezve, átirányítjuk a bejelentkezési oldalra
    header("Location: ../admin/login.php");
    exit();
}

$error_message = '';
$success_message = '';
$old_password_error = '';
$new_password_error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_SESSION['username'];  // Most már biztos, hogy létezik a 'username'

    // Ellenőrizzük, hogy a megfelelő adatokat küldték-e
    $new_username = isset($_POST['new_username']) ? $_POST['new_username'] : '';
    $old_password = isset($_POST['old_password']) ? $_POST['old_password'] : '';
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    // Ha nem törlés történik, hanem módosítások
    if (!isset($_POST['delete_account'])) {
        // Felhasználó keresése a Users táblában
        $stmt = $conn->prepare("SELECT * FROM Users WHERE Name = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Hibás régi jelszó ellenőrzése - csak akkor szükséges, ha jelszó módosítása van
        if (!empty($old_password) && !password_verify($old_password, $user['Password'])) {
            $old_password_error = "Hibás régi jelszó!";
        } else {
            // Felhasználónév frissítése, ha szükséges
            if (!empty($new_username)) {
                $update_username_stmt = $conn->prepare("UPDATE Users SET Name = ? WHERE Name = ?");
                $update_username_stmt->bind_param("ss", $new_username, $username);
                $update_username_stmt->execute();
                $_SESSION['username'] = $new_username; 
            }

            // Jelszó frissítése, ha szükséges
            if (!empty($new_password)) {
                // Ha az új jelszó és a megerősítés nem egyezik
                if ($new_password !== $confirm_password) {
                    $new_password_error = "Az új jelszó és megerősítése nem egyezik!";
                }
                // Ha az új jelszó nem elég erős
                elseif (strlen($new_password) < 8) {
                    $new_password_error = "Az új jelszónak legalább 8 karakter hosszúnak kell lennie!";
                } else {
                    $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_password_stmt = $conn->prepare("UPDATE Users SET Password = ? WHERE Name = ?");
                    $update_password_stmt->bind_param("ss", $hashed_new_password, $username);
                    $update_password_stmt->execute();
                }
            }
        }
    }

    // Ha törlés történik
    if (isset($_POST['delete_account'])) {
        // Fiók törlése
        $stmt = $conn->prepare("DELETE FROM Users WHERE Name = ?");
        $stmt->bind_param("s", $username);
        if ($stmt->execute()) {
            session_destroy(); // Bezárjuk a session-t
            header("Location: ../php/main.php"); // Átirányítás regisztrációs oldalra
            exit();
        } else {
            $error_message = "Hiba történt a fiók törlésekor!";
        }
    }
}

$conn->close();

?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beállítások</title>
    <!-- FontAwesome ikonok betöltése -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/settings.css">
    <link rel="shortcut icon" href="../images/Új projekt.png" type="image/x-icon">
</head>
<body>
    <div class="wrapper">
        <?php include 'header/header.php'; ?>

        <main>
            <div class="content">
                <h2>Beállítások</h2>

                <form method="POST" action="settings.php">
                    <div class="input-group">
                        <label for="new_username">Új felhasználónév</label>
                        <input type="text" name="new_username" id="new_username" placeholder="Új felhasználónév (opcionális)">
                    </div>
                    <div class="input-group">
                        <label for="old_password">Régi jelszó</label>
                        <input type="password" name="old_password" id="old_password" required placeholder="Régi jelszó">
                        <?php if (!empty($old_password_error)): ?>
                            <span class="error"><?php echo $old_password_error; ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="input-group">
                        <label for="new_password">Új jelszó</label>
                        <input type="password" name="new_password" id="new_password" placeholder="Új jelszó (opcionális)">
                    </div>
                    <div class="input-group">
                        <label for="confirm_password">Új jelszó megerősítése</label>
                        <input type="password" name="confirm_password" id="confirm_password" placeholder="Új jelszó megerősítése">
                        <?php if (!empty($new_password_error)): ?>
                            <span class="error"><?php echo $new_password_error; ?></span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="modify-account-btn">Módosítások mentése</button>
                </form>

                <!-- Fiók törlése gomb -->
                <form id="deleteForm" method="POST" action="settings.php">
                    <button type="button" class="delete-account-btn" onclick="showDeleteModal()">Fiók törlése</button>
                </form>

                <!-- Modális ablak -->
                <div id="deleteModal" class="modal">
                    <div class="modal-content">
                        <h3>Biztosan törölni akarja a fiókját?</h3>
                        <div class="modal-buttons">
                            <!-- A gomb most végrehajtja a törlést -->
                            <button type="button" class="delete-btn" onclick="deleteAccount()">Fiók törlése</button>
                            <button type="button" class="cancel-btn" onclick="closeModal()">Mégse</button>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include 'footer/footer.php'; ?>
    </div>

    <script src="../js/settings.js"></script>

</body>
</html>



