        // Modális ablak megjelenítése
        function showDeleteModal() {
            document.getElementById("deleteModal").style.display = "flex"; // Modális ablak megjelenítése
        }

        // Modális ablak bezárása
        function closeModal() {
            document.getElementById("deleteModal").style.display = "none"; // Modális ablak eltüntetése
        }

        // Fiók törlésének elindítása
        function deleteAccount() {
            // Az űrlap elküldése a fiók törléséhez
            var form = document.getElementById("deleteForm");
            var input = document.createElement("input");
            input.type = "hidden";
            input.name = "delete_account";
            input.value = "1"; // Jelöljük, hogy törlés történik
            form.appendChild(input);
            form.submit();
        }