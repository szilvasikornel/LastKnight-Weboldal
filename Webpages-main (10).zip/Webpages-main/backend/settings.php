<?php
session_start();  // Munkamenet indítása

include('../admin/connect.php');  // Adatbázis kapcsolat

// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['username'])) {
    header("Location: ../admin/login.php");
    exit();
}

$error_message = '';
$success_message = '';
$old_password_error = '';
$new_password_error = '';
$username_error = '';

// Ha a felhasználó elküldi az űrlapot
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_SESSION['username'];

    // Ha a felhasználó a fiókját törli
    if (isset($_POST['delete_account'])) {
        $delete_stmt = $conn->prepare("DELETE FROM Users WHERE Name = ?");
        $delete_stmt->bind_param("s", $username);
        $delete_stmt->execute();

        // Munkamenet törlése és átirányítás a főoldalra
        session_destroy();
        header("Location: main.php");
        exit();
    }

    // Adatok lekérése az űrlapról
    $new_username = isset($_POST['new_username']) ? trim($_POST['new_username']) : '';
    $old_password = isset($_POST['old_password']) ? $_POST['old_password'] : '';
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    // Jelenlegi felhasználó adatainak lekérése
    $stmt = $conn->prepare("SELECT * FROM Users WHERE Name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Felhasználónév módosítás
    if (!empty($new_username) && $new_username !== $username) {
        $check_stmt = $conn->prepare("SELECT * FROM Users WHERE Name = ?");
        $check_stmt->bind_param("s", $new_username);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $username_error = "Ez a felhasználónév már foglalt!";
        } else {
            $update_username_stmt = $conn->prepare("UPDATE Users SET Name = ? WHERE Name = ?");
            $update_username_stmt->bind_param("ss", $new_username, $username);
            $update_username_stmt->execute();
            $_SESSION['username'] = $new_username;
            $success_message = "Felhasználónév sikeresen frissítve!";
        }
    }

    // Jelszó módosítás
    if (!empty($old_password) && password_verify($old_password, $user['Password'])) {
        if (!empty($new_password)) {
            if ($new_password !== $confirm_password) {
                $new_password_error = "Az új jelszó és megerősítése nem egyezik!";
            } elseif (strlen($new_password) < 8) {
                $new_password_error = "Az új jelszónak legalább 8 karakter hosszúnak kell lennie!";
            } else {
                $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_password_stmt = $conn->prepare("UPDATE Users SET Password = ? WHERE Name = ?");
                $update_password_stmt->bind_param("ss", $hashed_new_password, $username);
                $update_password_stmt->execute();
                $success_message = "Jelszó sikeresen módosítva!";
            }
        }
    } else {
        $old_password_error = "Hibás régi jelszó!";
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beállítások</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/settings.css">
    <link rel="shortcut icon" href="../images/Új projekt.png" type="image/x-icon">
</head>
<body>
    <div class="wrapper">
        <?php include 'header/header.php'; ?>

        <main>
            <div class="content">
                <h2>Beállítások</h2>

                <form method="POST" action="settings.php">
                    <div class="input-group">
                        <label for="new_username">Új felhasználónév</label>
                        <input type="text" name="new_username" id="new_username" placeholder="Új felhasználónév (opcionális)">
                        <?php if (!empty($username_error)): ?>
                            <span class="error" style="color: white;"> <?php echo $username_error; ?> </span>
                        <?php endif; ?>
                    </div>
                    <div class="input-group">
                        <label for="old_password">Régi jelszó</label>
                        <input type="password" name="old_password" id="old_password" required placeholder="Régi jelszó">
                        <?php if (!empty($old_password_error)): ?>
                            <span class="error"><?php echo $old_password_error; ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="input-group">
                        <label for="new_password">Új jelszó</label>
                        <input type="password" name="new_password" id="new_password" placeholder="Új jelszó (opcionális)">
                    </div>
                    <div class="input-group">
                        <label for="confirm_password">Új jelszó megerősítése</label>
                        <input type="password" name="confirm_password" id="confirm_password" placeholder="Új jelszó megerősítése">
                        <?php if (!empty($new_password_error)): ?>
                            <span class="error"><?php echo $new_password_error; ?></span>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($success_message)): ?>
                        <div class="success-message" style="background-color: green; color: white; padding: 10px; text-align: center; margin-bottom: 15px; border-radius: 5px;">
                            <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>

                    <button type="submit" class="modify-account-btn">Módosítások mentése</button>
                     <!-- Fiók törlése gomb -->
                    <form id="deleteForm" method="POST" action="settings.php">
                        <button type="button" class="delete-account-btn" onclick="showDeleteModal()">Fiók törlése</button>
                    </form>

                    <!-- Modális ablak -->
                    <div id="deleteModal" class="modal">
                        <div class="modal-content">
                            <h3>Biztosan törölni akarja a fiókját?</h3>
                            <div class="modal-buttons">
                                <!-- A gomb most végrehajtja a törlést -->
                                <button type="button" class="delete-btn" onclick="deleteAccount()">Fiók törlése</button>
                                <button type="button" class="cancel-btn" onclick="closeModal()">Mégse</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </main>

        <?php include 'footer/footer.php'; ?>
    </div>

    <script src="../js/settings.js"></script>
</html>
