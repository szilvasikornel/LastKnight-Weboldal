<?php
include('../admin/connect.php');

$username_error = false;  // Kezdetben nincs hiba
$email_error = false;     // Kezdetben nincs hiba

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Ellenőrizzük, hogy létezik-e már a felhasználónév
    $stmt = $conn->prepare("SELECT * FROM Users WHERE Name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Felhasználónév már foglalt
        $username_error = true;
        $error_message = "Ez a felhasználónév már foglalt.";
    } else {
        // Ellenőrizzük, hogy létezik-e már a felhasználó email címe
        $stmt = $conn->prepare("SELECT * FROM Users WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $email_result = $stmt->get_result();

        if ($email_result->num_rows > 0) {
            // E-mail cím már foglalt
            $email_error = true;
            $error_message = "Ez az e-mail cím már használatban van.";
        } else {
            // Ha nincs foglalt felhasználónév vagy e-mail, regisztrálhatjuk az új felhasználót
            $stmt = $conn->prepare("INSERT INTO Users (Name, Email, Password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $password);
            $stmt->execute();
            
            header("Location: login.php?success=1");
            exit();
        }
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
    <link rel="stylesheet" href="../css/registerstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="shortcut icon" href="../images/Új projekt.png" type="image/x-icon">
</head>    
<body>
    <div class="wrapper1">

        <?php include '../backend/header/header.php'; ?> 

        <div class="tartalom">
            <div class="wrapper">
                <form method="POST" action="register.php" autocomplete="off" id="registerForm">
                    <h2>Regisztráció</h2>

                    <!-- Felhasználónév mező -->
                    <div class="input-group <?php echo isset($username_error) && $username_error ? 'has-error' : ''; ?>" id="username-group">
                        <input type="text" name="username" id="input" required value="<?php echo isset($username) ? $username : ''; ?>">
                        <label for="input" class="label">Felhasználónév</label>
                        <?php if (isset($username_error) && $username_error) { ?>
                            <span class="error-message"><?php echo $error_message; ?></span>
                        <?php } ?>
                    </div>

                    <!-- Email mező -->
                    <div class="input-group <?php echo isset($email_error) && $email_error ? 'has-error' : ''; ?>" id="email-group">
                        <input type="email" name="email" id="email-input" required value="<?php echo isset($email) ? $email : ''; ?>">
                        <label for="email-input" class="label">Email</label>
                        <?php if (isset($email_error) && $email_error) { ?>
                            <span class="error-message"><?php echo $error_message; ?></span>
                        <?php } ?>
                    </div>

                    <!-- Jelszó mező -->
                    <div class="input-group <?php echo isset($password_error) && $password_error ? 'has-error' : ''; ?>" id="password-group">
                        <input type="password" name="password" id="password-input" required>
                        <label for="password-input" class="label">Jelszó</label>
                        <span id="eye-icon" class="eye-icon" onclick="togglePasswordVisibility('password-input', 'eye-icon')">
                            <i class="fas fa-eye-slash"></i>
                        </span>
                        <span id="password-error" class="error-message"></span>
                    </div>


                    <div class="check" id="terms-group">
                        <label>
                            <input type="checkbox" id="terms-checkbox">
                            <span>Elfogadom a felhasználási feltételeket</span>
                        </label>
                        <span id="terms-error" class="error-message"></span>
                    </div>

                    <button type="submit">Regisztrálok</button>
                    <div class="signin">
                        <p>Már van fiókod? <a href="login.php">Bejelentkezés</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="../js/script.js"></script>
</body>
</html>

