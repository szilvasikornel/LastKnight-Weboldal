<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/contact.css">
    <!-- FontAwesome ikonok betöltése -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <title>Kapcsolat</title>
</head>
<body>
    <div class="wrapper">

        <div class="middle">
            <?php include 'header/header.php'; ?> 
        </div>

        <main class="middle">
            <div class="content">
                <h2 class="title">Lépjen velünk kapcsolatba!</h2>
                <p>Amennyiben kérdése van, visszajelzést küldene, vagy bármilyen javaslattal élne, ne habozzon felkeresni minket! Csapatunk mindig készen áll arra, hogy segítsen.</p>
                
                <div class="contact-info">
                    <h3>Elérhetőségeink</h3> 
                    <ul>
                        <li><strong>Email:</strong> <a href="mailto:lastknight1@gmail.com">lastknight1@gmail.com</a></li>
                        <li><strong>Telefonszám:</strong> +36 70 731 2192</li>
                        <li>
                            <a href="https://www.instagram.com/" target="_blank" class="social-icon">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="https://www.facebook.com/" target="_blank" class="social-icon">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                        </li>
                    </ul>
                </div>


                <p>Bátran lépjen velünk kapcsolatba bármilyen kérdés vagy visszajelzés esetén! Akár a játék során felmerült problémákról, játékmeneti kérdésekről, akár új ötletekről van szó, örömmel segítünk!</p>

            </div>
        </main>

        <?php include 'footer/footer.php'; ?> 

    </div>
    <script src="../js/dropdown.js"></script>
</body>
</html>
