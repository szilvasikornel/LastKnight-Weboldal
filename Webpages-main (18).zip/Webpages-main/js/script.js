document.getElementById('registerForm').addEventListener('submit', function(event) {
    let valid = true;

    // Reset the previous error styles and messages
    resetErrorStyles();

    // Jelszó ellenőrzés
    let password = document.getElementById('password-input').value;
    let passwordError = document.getElementById('password-error');
    if (password.length < 8) {
        passwordError.textContent = "A jelszónak legalább 8 karakter hosszúnak kell lennie.";
        document.getElementById('password-group').classList.add('error');
        valid = false;
    }

    // Felhasználási feltételek ellenőrzés
    let termsCheckbox = document.getElementById('terms-checkbox');
    let termsError = document.getElementById('terms-error');
    if (!termsCheckbox.checked) {
        termsError.textContent = "El kell fogadnod a felhasználási feltételeket.";
        document.getElementById('terms-group').classList.add('error');
        valid = false;
    }

    // Ha valami hibás, akkor ne küldje el a formot
    if (!valid) {
        event.preventDefault();
    }
});

function togglePasswordVisibility(passwordId, eyeIconId) {
    const passwordField = document.getElementById(passwordId);
    const eyeIcon = document.getElementById(eyeIconId);

    if (passwordField.type === "password") {
        passwordField.type = "text";
        eyeIcon.innerHTML = '<i class="fas fa-eye"></i>';
    } else {
        passwordField.type = "password";
        eyeIcon.innerHTML = '<i class="fas fa-eye-slash"></i>';
    }
}

function resetErrorStyles() {
    // Reset previous error messages and styles
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach((el) => {
        el.textContent = '';
    });

    const errorGroups = document.querySelectorAll('.input-group, .check');
    errorGroups.forEach((group) => {
        group.classList.remove('has-error');  // has-error osztály eltávolítása
    });
}

